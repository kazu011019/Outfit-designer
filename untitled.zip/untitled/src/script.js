<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StyleAI - AI Outfit Generator</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        serif: ['Playfair Display', 'serif'],
                    },
                    colors: {
                        primary: '#8B5CF6',
                        secondary: '#EC4899',
                        accent: '#3B82F6',
                        dark: '#0F0F1A',
                        darker: '#0A0A12',
                        surface: '#1A1A2E',
                        'surface-light': '#252542',
                    },
                    animation: {
                        'float': 'float 6s ease-in-out infinite',
                        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                        'shimmer': 'shimmer 2s linear infinite',
                        'slide-up': 'slideUp 0.5s ease-out',
                        'fade-in': 'fadeIn 0.3s ease-out',
                    },
                    keyframes: {
                        float: {
                            '0%, 100%': { transform: 'translateY(0)' },
                            '50%': { transform: 'translateY(-20px)' },
                        },
                        shimmer: {
                            '0%': { backgroundPosition: '-1000px 0' },
                            '100%': { backgroundPosition: '1000px 0' },
                        },
                        slideUp: {
                            '0%': { transform: 'translateY(20px)', opacity: '0' },
                            '100%': { transform: 'translateY(0)', opacity: '1' },
                        },
                        fadeIn: {
                            '0%': { opacity: '0' },
                            '100%': { opacity: '1' },
                        }
                    }
                }
            }
        }
    </script>
    <style>
        body {
            background-color: #0A0A12;
            color: #ffffff;
            overflow-x: hidden;
        }
        
        .glass {
            background: rgba(26, 26, 46, 0.7);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.08);
        }
        
        .glass-strong {
            background: rgba(26, 26, 46, 0.9);
            backdrop-filter: blur(30px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .gradient-text {
            background: linear-gradient(135deg, #8B5CF6, #EC4899, #3B82F6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .gradient-border {
            position: relative;
        }
        
        .gradient-border::before {
            content: '';
            position: absolute;
            inset: -2px;
            border-radius: inherit;
            padding: 2px;
            background: linear-gradient(135deg, #8B5CF6, #EC4899, #3B82F6);
            -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            -webkit-mask-composite: xor;
            mask-composite: exclude;
            pointer-events: none;
        }
        
        .particle {
            position: absolute;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(139, 92, 246, 0.4), transparent);
            pointer-events: none;
        }
        
        .outfit-card {
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .outfit-card:hover {
            transform: translateY(-8px) scale(1.02);
            box-shadow: 0 20px 40px rgba(139, 92, 246, 0.2);
        }
        
        .category-btn {
            transition: all 0.3s ease;
        }
        
        .category-btn.active {
            background: linear-gradient(135deg, rgba(139, 92, 246, 0.3), rgba(236, 72, 153, 0.3));
            border-color: rgba(139, 92, 246, 0.6);
            box-shadow: 0 0 20px rgba(139, 92, 246, 0.3);
        }
        
        .color-swatch {
            transition: all 0.2s ease;
            cursor: pointer;
        }
        
        .color-swatch:hover {
            transform: scale(1.2);
            box-shadow: 0 0 15px currentColor;
        }
        
        .color-swatch.selected {
            transform: scale(1.25);
            box-shadow: 0 0 20px currentColor;
            border: 2px solid white;
        }
        
        .slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 100%;
            height: 6px;
            border-radius: 3px;
            background: linear-gradient(90deg, #8B5CF6, #EC4899);
            outline: none;
        }
        
        .slider-thumb::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: white;
            cursor: pointer;
            box-shadow: 0 0 15px rgba(139, 92, 246, 0.5);
            transition: transform 0.2s;
        }
        
        .slider-thumb::-webkit-slider-thumb:hover {
            transform: scale(1.2);
        }
        
        .loading-ring {
            border: 3px solid rgba(139, 92, 246, 0.2);
            border-top: 3px solid #8B5CF6;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .toast {
            animation: slideInRight 0.4s ease-out, fadeOut 0.4s ease-out 2.6s;
        }
        
        @keyframes slideInRight {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }
        
        .scroll-hidden::-webkit-scrollbar {
            width: 6px;
        }
        
        .scroll-hidden::-webkit-scrollbar-track {
            background: transparent;
        }
        
        .scroll-hidden::-webkit-scrollbar-thumb {
            background: rgba(139, 92, 246, 0.3);
            border-radius: 3px;
        }
        
        .neon-glow {
            box-shadow: 0 0 30px rgba(139, 92, 246, 0.4), 0 0 60px rgba(236, 72, 153, 0.2);
        }
        
        .image-placeholder {
            background: linear-gradient(135deg, #1A1A2E, #252542);
            position: relative;
            overflow: hidden;
        }
        
        .image-placeholder::after {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.05), transparent);
            animation: shimmer 2s infinite;
        }
        
        .wardrobe-item {
            transition: all 0.3s ease;
        }
        
        .wardrobe-item:hover {
            transform: translateX(5px);
            background: rgba(139, 92, 246, 0.1);
        }
        
        .progress-bar {
            transition: width 0.5s ease;
        }

        .outfit-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .outfit-card:hover .outfit-img {
            transform: scale(1.05);
        }

        .img-fallback {
            position: absolute;
            inset: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #1A1A2E, #252542);
        }

        .source-badge {
            position: absolute;
            bottom: 8px;
            left: 8px;
            padding: 4px 10px;
            border-radius: 20px;
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(10px);
            font-size: 10px;
            font-weight: 600;
            color: white;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .source-badge img {
            width: 12px;
            height: 12px;
            border-radius: 50%;
        }
    </style>
</head>
<body class="font-sans antialiased">

    <!-- Background Particles -->
    <div id="particles" class="fixed inset-0 pointer-events-none z-0"></div>

    <!-- Navigation -->
    <nav class="fixed top-0 w-full z-50 glass border-b border-white/5">
        <div class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold text-lg shadow-lg shadow-primary/30">
                    S
                </div>
                <span class="text-xl font-bold tracking-tight">Style<span class="gradient-text">AI</span></span>
            </div>
            <div class="hidden md:flex items-center gap-8 text-sm font-medium text-gray-400">
                <a href="#" class="hover:text-white transition-colors">Generator</a>
                <a href="#" class="hover:text-white transition-colors">Gallery</a>
                <a href="#" class="hover:text-white transition-colors">Trends</a>
                <button onclick="toggleWardrobe()" class="flex items-center gap-2 px-4 py-2 rounded-lg bg-surface hover:bg-surface-light transition-colors border border-white/10">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"></path></svg>
                    Wardrobe <span id="wardrobe-count" class="px-2 py-0.5 rounded-full bg-primary/20 text-primary text-xs">0</span>
                </button>
            </div>
            <button class="md:hidden text-white" onclick="toggleWardrobe()">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
            </button>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="relative pt-32 pb-20 px-6 overflow-hidden">
        <div class="max-w-7xl mx-auto text-center relative z-10">
            <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full glass text-sm font-medium text-primary mb-8 animate-fade-in">
                <span class="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                Powered by Live Image Search
            </div>
            <h1 class="text-5xl md:text-7xl font-bold mb-6 leading-tight">
                Design Your <br>
                <span class="font-serif italic gradient-text">Perfect Outfit</span>
            </h1>
            <p class="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto mb-10 leading-relaxed">
                Select your style and watch AI fetch real outfit images from the web instantly. No stock photos — fresh fashion every time.
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <button onclick="scrollToGenerator()" class="px-8 py-4 rounded-xl bg-gradient-to-r from-primary to-secondary text-white font-semibold text-lg shadow-lg shadow-primary/30 hover:shadow-primary/50 transition-all hover:scale-105">
                    Start Creating
                </button>
                <button onclick="showDemo()" class="px-8 py-4 rounded-xl glass text-white font-semibold text-lg hover:bg-white/5 transition-all border border-white/10">
                    View Demo
                </button>
            </div>
        </div>
        
        <!-- Floating Elements -->
        <div class="absolute top-40 left-10 w-20 h-20 rounded-2xl bg-primary/10 backdrop-blur-xl border border-primary/20 animate-float hidden lg:block" style="animation-delay: 0s;"></div>
        <div class="absolute top-60 right-20 w-16 h-16 rounded-full bg-secondary/10 backdrop-blur-xl border border-secondary/20 animate-float hidden lg:block" style="animation-delay: 2s;"></div>
        <div class="absolute bottom-20 left-1/4 w-24 h-24 rounded-3xl bg-accent/10 backdrop-blur-xl border border-accent/20 animate-float hidden lg:block" style="animation-delay: 4s;"></div>
    </section>

    <!-- Generator Interface -->
    <section id="generator" class="relative py-20 px-6">
        <div class="max-w-7xl mx-auto">
            <div class="grid lg:grid-cols-3 gap-8">
                
                <!-- Controls Panel -->
                <div class="lg:col-span-1 space-y-6">
                    <div class="glass rounded-2xl p-6 space-y-6">
                        <h2 class="text-2xl font-bold flex items-center gap-2">
                            <svg class="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"></path></svg>
                            Style Controls
                        </h2>

                        <!-- Category Selection -->
                        <div>
                            <label class="block text-sm font-medium text-gray-400 mb-3">Category</label>
                            <div class="grid grid-cols-2 gap-2">
                                <button onclick="selectCategory('casual')" class="category-btn active px-4 py-3 rounded-xl border border-white/10 bg-surface hover:bg-surface-light text-sm font-medium" data-category="casual">
                                    👕 Casual
                                </button>
                                <button onclick="selectCategory('formal')" class="category-btn px-4 py-3 rounded-xl border border-white/10 bg-surface hover:bg-surface-light text-sm font-medium" data-category="formal">
                                    👔 Formal
                                </button>
                                <button onclick="selectCategory('streetwear')" class="category-btn px-4 py-3 rounded-xl border border-white/10 bg-surface hover:bg-surface-light text-sm font-medium" data-category="streetwear">
                                    🛹 Streetwear
                                </button>
                                <button onclick="selectCategory('vintage')" class="category-btn px-4 py-3 rounded-xl border border-white/10 bg-surface hover:bg-surface-light text-sm font-medium" data-category="vintage">
                                    🎩 Vintage
                                </button>
                                <button onclick="selectCategory('athleisure')" class="category-btn px-4 py-3 rounded-xl border border-white/10 bg-surface hover:bg-surface-light text-sm font-medium" data-category="athleisure">
                                    🏃 Athleisure
                                </button>
                                <button onclick="selectCategory('bohemian')" class="category-btn px-4 py-3 rounded-xl border border-white/10 bg-surface hover:bg-surface-light text-sm font-medium" data-category="bohemian">
                                    🌸 Bohemian
                                </button>
                            </div>
                        </div>

                        <!-- Color Palette -->
                        <div>
                            <label class="block text-sm font-medium text-gray-400 mb-3">Color Palette</label>
                            <div class="flex flex-wrap gap-3">
                                <div class="color-swatch selected w-10 h-10 rounded-full bg-gradient-to-br from-gray-800 to-black" data-color="monochrome" onclick="selectColor(this)" title="Monochrome"></div>
                                <div class="color-swatch w-10 h-10 rounded-full bg-gradient-to-br from-blue-600 to-blue-400" data-color="blue" onclick="selectColor(this)" title="Ocean Blue"></div>
                                <div class="color-swatch w-10 h-10 rounded-full bg-gradient-to-br from-red-600 to-orange-500" data-color="warm" onclick="selectColor(this)" title="Warm Sunset"></div>
                                <div class="color-swatch w-10 h-10 rounded-full bg-gradient-to-br from-emerald-600 to-teal-400" data-color="green" onclick="selectColor(this)" title="Forest Green"></div>
                                <div class="color-swatch w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-pink-500" data-color="purple" onclick="selectColor(this)" title="Royal Purple"></div>
                                <div class="color-swatch w-10 h-10 rounded-full bg-gradient-to-br from-yellow-400 to-amber-600" data-color="gold" onclick="selectColor(this)" title="Golden Hour"></div>
                                <div class="color-swatch w-10 h-10 rounded-full bg-gradient-to-br from-rose-400 to-pink-600" data-color="pastel" onclick="selectColor(this)" title="Soft Pastel"></div>
                                <div class="color-swatch w-10 h-10 rounded-full bg-gradient-to-br from-slate-700 to-slate-500" data-color="neutral" onclick="selectColor(this)" title="Earth Neutral"></div>
                            </div>
                        </div>

                        <!-- Style Intensity -->
                        <div>
                            <div class="flex justify-between mb-2">
                                <label class="text-sm font-medium text-gray-400">Creativity Level</label>
                                <span id="intensity-value" class="text-sm font-medium text-primary">75%</span>
                            </div>
                            <input type="range" min="0" max="100" value="75" class="slider-thumb" id="intensity-slider" oninput="updateIntensity(this.value)">
                            <div class="flex justify-between text-xs text-gray-500 mt-1">
                                <span>Classic</span>
                                <span>Avant-Garde</span>
                            </div>
                        </div>

                        <!-- Season -->
                        <div>
                            <label class="block text-sm font-medium text-gray-400 mb-3">Season</label>
                            <div class="flex gap-2">
                                <button onclick="selectSeason('spring')" class="season-btn flex-1 py-2 rounded-lg border border-white/10 bg-surface hover:bg-surface-light text-sm transition-all" data-season="spring">🌸 Spring</button>
                                <button onclick="selectSeason('summer')" class="season-btn flex-1 py-2 rounded-lg border border-white/10 bg-surface hover:bg-surface-light text-sm transition-all active-season" data-season="summer">☀️ Summer</button>
                                <button onclick="selectSeason('fall')" class="season-btn flex-1 py-2 rounded-lg border border-white/10 bg-surface hover:bg-surface-light text-sm transition-all" data-season="fall">🍂 Fall</button>
                                <button onclick="selectSeason('winter')" class="season-btn flex-1 py-2 rounded-lg border border-white/10 bg-surface hover:bg-surface-light text-sm transition-all" data-season="winter">❄️ Winter</button>
                            </div>
                        </div>

                        <!-- Generate Button -->
                        <button onclick="generateOutfit()" id="generate-btn" class="w-full py-4 rounded-xl bg-gradient-to-r from-primary via-secondary to-accent text-white font-bold text-lg shadow-lg shadow-primary/30 hover:shadow-primary/50 transition-all hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                            Search & Generate
                        </button>
                    </div>

                    <!-- Quick Stats -->
                    <div class="glass rounded-2xl p-6 grid grid-cols-3 gap-4 text-center">
                        <div>
                            <div class="text-2xl font-bold gradient-text">Live</div>
                            <div class="text-xs text-gray-400 mt-1">Images</div>
                        </div>
                        <div>
                            <div class="text-2xl font-bold gradient-text">Unsplash</div>
                            <div class="text-xs text-gray-400 mt-1">Source</div>
                        </div>
                        <div>
                            <div class="text-2xl font-bold gradient-text">2.5s</div>
                            <div class="text-xs text-gray-400 mt-1">Fetch Time</div>
                        </div>
                    </div>
                </div>

                <!-- Results Area -->
                <div class="lg:col-span-2">
                    <!-- Loading State -->
                    <div id="loading-state" class="hidden glass rounded-2xl p-12 text-center">
                        <div class="loading-ring w-16 h-16 mx-auto mb-6"></div>
                        <h3 class="text-xl font-semibold mb-2">Searching the web for outfits...</h3>
                        <p class="text-gray-400 text-sm mb-8" id="loading-text">Connecting to image database</p>
                        
                        <div class="max-w-md mx-auto space-y-3">
                            <div class="flex items-center gap-3">
                                <div id="step1" class="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs">1</div>
                                <div class="flex-1 h-2 bg-surface rounded-full overflow-hidden">
                                    <div class="progress-bar h-full bg-primary rounded-full" style="width: 0%"></div>
                                </div>
                                <span class="text-xs text-gray-500">Query Build</span>
                            </div>
                            <div class="flex items-center gap-3">
                                <div id="step2" class="w-8 h-8 rounded-full bg-surface flex items-center justify-center text-xs">2</div>
                                <div class="flex-1 h-2 bg-surface rounded-full overflow-hidden">
                                    <div class="progress-bar h-full bg-secondary rounded-full" style="width: 0%"></div>
                                </div>
                                <span class="text-xs text-gray-500">Image Fetch</span>
                            </div>
                            <div class="flex items-center gap-3">
                                <div id="step3" class="w-8 h-8 rounded-full bg-surface flex items-center justify-center text-xs">3</div>
                                <div class="flex-1 h-2 bg-surface rounded-full overflow-hidden">
                                    <div class="progress-bar h-full bg-accent rounded-full" style="width: 0%"></div>
                                </div>
                                <span class="text-xs text-gray-500">Render Cards</span>
                            </div>
                        </div>
                    </div>

                    <!-- Empty State -->
                    <div id="empty-state" class="glass rounded-2xl p-12 text-center border border-dashed border-white/10">
                        <div class="w-24 h-24 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                            <svg class="w-12 h-12 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                        </div>
                        <h3 class="text-xl font-semibold mb-2">Ready to Search</h3>
                        <p class="text-gray-400 max-w-md mx-auto">Select your preferences and click "Search & Generate" to fetch real outfit images from Unsplash.</p>
                    </div>

                    <!-- Results Grid -->
                    <div id="results-grid" class="hidden grid grid-cols-1 md:grid-cols-2 gap-6"></div>
                </div>
            </div>
        </div>
    </section>

    <!-- Wardrobe Sidebar -->
    <div id="wardrobe-sidebar" class="fixed right-0 top-0 h-full w-full md:w-96 glass-strong z-50 transform translate-x-full transition-transform duration-500 border-l border-white/10">
        <div class="p-6 h-full flex flex-col">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-bold flex items-center gap-2">
                    <svg class="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"></path></svg>
                    My Wardrobe
                </h2>
                <button onclick="toggleWardrobe()" class="p-2 rounded-lg hover:bg-white/5 transition-colors">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>
            
            <div id="wardrobe-list" class="flex-1 overflow-y-auto scroll-hidden space-y-4">
                <div class="text-center text-gray-500 py-12">
                    <svg class="w-12 h-12 mx-auto mb-3 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path></svg>
                    <p class="text-sm">No saved outfits yet</p>
                    <p class="text-xs mt-1">Generate and save your favorites!</p>
                </div>
            </div>
            
            <div class="mt-6 pt-6 border-t border-white/10">
                <button onclick="clearWardrobe()" class="w-full py-3 rounded-xl border border-red-500/30 text-red-400 hover:bg-red-500/10 transition-colors text-sm font-medium">
                    Clear Wardrobe
                </button>
            </div>
        </div>
    </div>

    <!-- Overlay -->
    <div id="overlay" class="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 hidden opacity-0 transition-opacity duration-300" onclick="toggleWardrobe()"></div>

    <!-- Toast Container -->
    <div id="toast-container" class="fixed bottom-6 right-6 z-50 space-y-3"></div>

    <script>
        // State
        let currentCategory = 'casual';
        let currentColor = 'monochrome';
        let currentSeason = 'summer';
        let intensity = 75;
        let wardrobe = [];
        let isGenerating = false;
        let currentImages = [];

        // Search query mappings
        const searchQueries = {
            casual: ['casual outfit aesthetic', 'everyday style fashion', 'relaxed outfit look', 'casual chic street style'],
            formal: ['formal suit outfit', 'business attire elegant', 'evening formal wear', 'classy outfit look'],
            streetwear: ['streetwear outfit urban', 'hypebeast fashion', 'skater style outfit', 'urban street style'],
            vintage: ['vintage retro outfit', '70s fashion aesthetic', 'retro style clothing', 'classic vintage look'],
            athleisure: ['athleisure workout outfit', 'gym street style', 'sporty chic fashion', 'activewear aesthetic'],
            bohemian: ['bohemian boho outfit', 'boho chic fashion', 'festival outfit look', 'boho maxi dress style']
        };

        const colorKeywords = {
            monochrome: 'black white',
            blue: 'blue navy',
            warm: 'red orange warm',
            green: 'green olive',
            purple: 'purple violet',
            gold: 'gold yellow beige',
            pastel: 'pastel pink soft',
            neutral: 'beige brown neutral'
        };

        const colorSchemes = {
            monochrome: { bg: 'from-gray-800 to-black', accent: 'gray', hex: '#6B7280' },
            blue: { bg: 'from-blue-600 to-cyan-400', accent: 'blue', hex: '#3B82F6' },
            warm: { bg: 'from-red-600 to-orange-500', accent: 'orange', hex: '#F97316' },
            green: { bg: 'from-emerald-600 to-teal-400', accent: 'emerald', hex: '#10B981' },
            purple: { bg: 'from-purple-600 to-pink-500', accent: 'purple', hex: '#8B5CF6' },
            gold: { bg: 'from-yellow-500 to-amber-600', accent: 'yellow', hex: '#F59E0B' },
            pastel: { bg: 'from-rose-300 to-pink-400', accent: 'pink', hex: '#EC4899' },
            neutral: { bg: 'from-stone-600 to-stone-400', accent: 'stone', hex: '#78716C' }
        };

        // Initialize Particles
        function initParticles() {
            const container = document.getElementById('particles');
            for (let i = 0; i < 30; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                const size = Math.random() * 4 + 2;
                particle.style.width = size + 'px';
                particle.style.height = size + 'px';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.top = Math.random() * 100 + '%';
                particle.style.opacity = Math.random() * 0.5 + 0.1;
                particle.style.animation = `float ${Math.random() * 10 + 10}s ease-in-out infinite`;
                particle.style.animationDelay = Math.random() * 5 + 's';
                container.appendChild(particle);
            }
        }

        // Category Selection
        function selectCategory(category) {
            currentCategory = category;
            document.querySelectorAll('.category-btn').forEach(btn => {
                btn.classList.toggle('active', btn.dataset.category === category);
            });
        }

        // Color Selection
        function selectColor(element) {
            currentColor = element.dataset.color;
            document.querySelectorAll('.color-swatch').forEach(swatch => {
                swatch.classList.toggle('selected', swatch === element);
            });
        }

        // Season Selection
        function selectSeason(season) {
            currentSeason = season;
            document.querySelectorAll('.season-btn').forEach(btn => {
                if (btn.dataset.season === season) {
                    btn.classList.add('active-season', 'bg-primary/20', 'border-primary/50', 'text-primary');
                    btn.classList.remove('bg-surface', 'border-white/10');
                } else {
                    btn.classList.remove('active-season', 'bg-primary/20', 'border-primary/50', 'text-primary');
                    btn.classList.add('bg-surface', 'border-white/10');
                }
            });
        }

        // Intensity Update
        function updateIntensity(value) {
            intensity = value;
            document.getElementById('intensity-value').textContent = value + '%';
        }

        // Fetch images from Unsplash
        async function fetchOutfitImages(query, count = 4) {
            // Using Unsplash Source API (free, no key needed for demo)
            const images = [];
            const queries = searchQueries[currentCategory];
            const colorQ = colorKeywords[currentColor];
            const seasonQ = currentSeason;
            
            for (let i = 0; i < count; i++) {
                const baseQuery = queries[Math.floor(Math.random() * queries.length)];
                const fullQuery = `${baseQuery} ${colorQ} ${seasonQ} fashion`;
                // Add random param to prevent caching
                const randomParam = Math.floor(Math.random() * 10000);
                const url = `https://source.unsplash.com/600x800/?${encodeURIComponent(fullQuery)}&sig=${randomParam}`;
                
                // Try to get actual image data via Unsplash API if available, otherwise use source URL
                // For demo, we'll construct proper Unsplash URLs
                const unsplashUrl = `https://images.unsplash.com/photo-${getRandomPhotoId()}?w=600&h=800&fit=crop&q=80`;
                images.push({
                    url: unsplashUrl,
                    query: fullQuery,
                    fallback: `https://source.unsplash.com/600x800/?${encodeURIComponent(fullQuery)}&sig=${randomParam}`
                });
            }
            return images;
        }

        // Generate random Unsplash photo IDs for variety
        function getRandomPhotoId() {
            const ids = [
                '1515886657613-9f3515b0c78f', '1529139574466-a303027c1d8b', '1483985988355-763728e1935b',
                '1490481651871-32d2e7cd4c63', '1509631179647-0177331693ae', '1512436991641-6745cdb1723f',
                '1496747611176-843222e1e57c', '1487222477894-8943e1f3d5c8', '1503342216724-4b45e6c4474e',
                '1492707892479-40f81c1e1971', '1485968579580-b6d095142e6e', '1516762689617-e1cffcef479d',
                '1520006403909-837d6e1f7f4a', '1496747611176-843222e1e57c', '1483985988355-763728e1935b',
                '1509631179647-0177331693ae', '1515886657613-9f3515b0c78f', '1529139574466-a303027c1d8b',
                '1490481651871-32d2e7cd4c63', '1503342216724-4b45e6c4474e', '1512436991641-6745cdb1723f',
                '1487222477894-8943e1f3d5c8', '1492707892479-40f81c1e1971', '1485968579580-b6d095142e6e'
            ];
            return ids[Math.floor(Math.random() * ids.length)];
        }

        // Better approach: Use Unsplash API with proper search
        async function searchUnsplash(query, perPage = 4) {
            // Note: In production, use your own Unsplash Access Key
            // For demo purposes, we'll use a public approach with source.unsplash
            const searchTerms = searchQueries[currentCategory];
            const colorTerm = colorKeywords[currentColor];
            const queries = [];
            
            for (let i = 0; i < perPage; i++) {
                const term = searchTerms[Math.floor(Math.random() * searchTerms.length)];
                queries.push(`${term} ${colorTerm} ${currentSeason}`);
            }
            
            return queries;
        }

        // Generate Outfit
        async function generateOutfit() {
            if (isGenerating) return;
            isGenerating = true;

            const btn = document.getElementById('generate-btn');
            const originalText = btn.innerHTML;
            btn.innerHTML = '<div class="loading-ring w-5 h-5"></div> Searching...';
            btn.disabled = true;

            // Show loading state
            document.getElementById('empty-state').classList.add('hidden');
            document.getElementById('results-grid').classList.add('hidden');
            document.getElementById('loading-state').classList.remove('hidden');

            // Step 1: Build Query
            await new Promise(resolve => setTimeout(resolve, 400));
            document.getElementById('loading-text').textContent = 'Building search query...';
            document.querySelectorAll('.progress-bar')[0].style.width = '100%';
            document.getElementById('step1').classList.add('bg-primary', 'text-white');
            document.getElementById('step1').classList.remove('bg-surface');

            // Step 2: Fetch Images
            await new Promise(resolve => setTimeout(resolve, 600));
            document.getElementById('loading-text').textContent = 'Fetching images from Unsplash...';
            document.querySelectorAll('.progress-bar')[1].style.width = '100%';
            document.getElementById('step2').classList.add('bg-primary', 'text-white');
            document.getElementById('step2').classList.remove('bg-surface');

            // Build search queries and generate results with real image URLs
            const searchTerms = searchQueries[currentCategory];
            const colorTerm = colorKeywords[currentColor];
            const results = [];
            
            for (let i = 0; i < 4; i++) {
                const term = searchTerms[Math.floor(Math.random() * searchTerms.length)];
                const fullQuery = `${term} ${colorTerm} ${currentSeason}`;
                const randomId = Math.floor(Math.random() * 100000);
                
                // Use Unsplash Source for real dynamic images
                const imageUrl = `https://source.unsplash.com/600x800/?${encodeURIComponent(fullQuery)}&sig=${randomId}`;
                
                results.push({
                    id: Date.now() + i,
                    style: generateStyleName(),
                    items: generateItems(),
                    color: colorSchemes[currentColor],
                    confidence: Math.floor(85 + Math.random() * 14),
                    season: currentSeason,
                    category: currentCategory,
                    imageUrl: imageUrl,
                    query: fullQuery,
                    photographer: 'Unsplash'
                });
            }

            currentImages = results;

            // Step 3: Render
            await new Promise(resolve => setTimeout(resolve, 500));
            document.getElementById('loading-text').textContent = 'Rendering outfit cards...';
            document.querySelectorAll('.progress-bar')[2].style.width = '100%';
            document.getElementById('step3').classList.add('bg-primary', 'text-white');
            document.getElementById('step3').classList.remove('bg-surface');

            await new Promise(resolve => setTimeout(resolve, 400));

            displayResults(results);

            // Reset UI
            document.getElementById('loading-state').classList.add('hidden');
            document.getElementById('results-grid').classList.remove('hidden');
            
            btn.innerHTML = originalText;
            btn.disabled = false;
            isGenerating = false;

            // Reset progress bars
            document.querySelectorAll('.progress-bar').forEach(bar => bar.style.width = '0%');
            [1, 2, 3].forEach(i => {
                document.getElementById(`step${i}`).classList.remove('bg-primary', 'text-white');
                document.getElementById(`step${i}`).classList.add('bg-surface');
            });

            showToast('✨ Real outfit images fetched from Unsplash!', 'success');
        }

        function generateStyleName() {
            const styles = {
                casual: ['Weekend Comfort', 'Coffee Shop Vibes', 'Urban Explorer', 'Lazy Sunday', 'Street Casual'],
                formal: ['Boardroom Elite', 'Evening Gala', 'Wedding Guest', 'Business Casual', 'Cocktail Hour'],
                streetwear: ['Hypebeast', 'Skater Boy', 'Urban Ninja', 'Retro Revival', 'Tech Wear'],
                vintage: ['50s Pin-up', '70s Bohemian', '90s Grunge', 'Old Hollywood', 'Retro Chic'],
                athleisure: ['Gym to Street', 'Yoga Flow', 'Morning Run', 'Post-Workout', 'Active Lifestyle'],
                bohemian: ['Festival Ready', 'Beach Sunset', 'Desert Wanderer', 'Garden Party', 'Boho Bride']
            };
            const list = styles[currentCategory] || styles.casual;
            return list[Math.floor(Math.random() * list.length)];
        }

        function generateItems() {
            const items = {
                casual: ['Oversized Cotton Tee', 'Relaxed Fit Jeans', 'White Sneakers', 'Canvas Tote Bag', 'Minimalist Watch'],
                formal: ['Tailored Blazer', 'Crisp Dress Shirt', 'Pleated Trousers', 'Leather Oxford Shoes', 'Silk Tie'],
                streetwear: ['Graphic Hoodie', 'Cargo Pants', 'High-Top Sneakers', 'Crossbody Bag', 'Statement Cap'],
                vintage: ['High-Waisted Trousers', 'Silk Blouse', 'Vintage Leather Belt', 'Loafers', 'Cat-Eye Sunglasses'],
                athleisure: ['Performance Leggings', 'Sports Bra', 'Windbreaker Jacket', 'Running Shoes', 'Fitness Tracker'],
                bohemian: ['Flowy Maxi Dress', 'Fringe Cardigan', 'Ankle Boots', 'Layered Necklaces', 'Woven Handbag']
            };
            const list = items[currentCategory] || items.casual;
            return [...list].sort(() => 0.5 - Math.random()).slice(0, 3 + Math.floor(Math.random() * 2));
        }

        function displayResults(results) {
            const grid = document.getElementById('results-grid');
            grid.innerHTML = '';

            results.forEach((outfit, index) => {
                const card = document.createElement('div');
                card.className = 'outfit-card glass rounded-2xl overflow-hidden border border-white/5 animate-slide-up';
                card.style.animationDelay = `${index * 0.1}s`;

                const isSaved = wardrobe.some(w => w.id === outfit.id);

                card.innerHTML = `
                    <div class="image-placeholder h-64 relative group overflow-hidden">
                        <img 
                            src="${outfit.imageUrl}" 
                            alt="${outfit.style}"
                            class="outfit-img"
                            onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
                            loading="lazy"
                        >
                        <div class="img-fallback" style="display: none;">
                            <div class="text-center">
                                <div class="w-20 h-20 mx-auto mb-3 rounded-full bg-white/10 backdrop-blur-xl flex items-center justify-center text-4xl">
                                    ${getCategoryEmoji(outfit.category)}
                                </div>
                                <p class="text-white/80 font-medium text-lg">${outfit.style}</p>
                                <p class="text-white/40 text-xs mt-2">Image loading...</p>
                            </div>
                        </div>
                        <div class="absolute top-4 right-4 px-3 py-1 rounded-full bg-black/50 backdrop-blur-md text-xs font-medium text-white border border-white/10">
                            ${outfit.confidence}% Match
                        </div>
                        <div class="source-badge">
                            <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm0 22c-5.523 0-10-4.477-10-10S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/></svg>
                            Unsplash
                        </div>
                        <div class="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-between p-4">
                            <button onclick="tryOnOutfit(${outfit.id})" class="px-4 py-2 rounded-lg bg-white/20 backdrop-blur-md hover:bg-white/30 transition-colors text-sm font-medium">
                                👁️ Preview
                            </button>
                            <button onclick="saveOutfit(${outfit.id})" class="px-4 py-2 rounded-lg ${isSaved ? 'bg-primary/40' : 'bg-white/20'} backdrop-blur-md hover:bg-primary/30 transition-colors text-sm font-medium">
                                ${isSaved ? '✓ Saved' : '❤️ Save'}
                            </button>
                        </div>
                    </div>
                    <div class="p-5">
                        <div class="flex items-center justify-between mb-3">
                            <h3 class="font-bold text-lg">${outfit.style}</h3>
                            <span class="px-2 py-1 rounded-md bg-${outfit.color.accent}-500/20 text-${outfit.color.accent}-400 text-xs font-medium capitalize">
                                ${outfit.season}
                            </span>
                        </div>
                        <div class="space-y-2 mb-4">
                            ${outfit.items.map(item => `
                                <div class="flex items-center gap-2 text-sm text-gray-400">
                                    <div class="w-1.5 h-1.5 rounded-full bg-${outfit.color.accent}-500"></div>
                                    ${item}
                                </div>
                            `).join('')}
                        </div>
                        <div class="flex gap-2">
                            <button onclick="saveOutfit(${outfit.id})" class="flex-1 py-2.5 rounded-xl border border-white/10 hover:bg-white/5 transition-colors text-sm font-medium flex items-center justify-center gap-2">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"></path></svg>
                                ${isSaved ? 'Saved' : 'Save'}
                            </button>
                            <button onclick="shareOutfit(${outfit.id})" class="px-4 py-2.5 rounded-xl border border-white/10 hover:bg-white/5 transition-colors text-sm font-medium">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"></path></svg>
                            </button>
                        </div>
                    </div>
                `;
                
                card.dataset.outfit = JSON.stringify(outfit);
                grid.appendChild(card);
            });
        }

        function getCategoryEmoji(category) {
            const emojis = {
                casual: '👕', formal: '👔', streetwear: '🛹', 
                vintage: '🎩', athleisure: '🏃', bohemian: '🌸'
            };
            return emojis[category] || '✨';
        }

        // Wardrobe Functions
        function toggleWardrobe() {
            const sidebar = document.getElementById('wardrobe-sidebar');
            const overlay = document.getElementById('overlay');
            
            if (sidebar.classList.contains('translate-x-full')) {
                sidebar.classList.remove('translate-x-full');
                overlay.classList.remove('hidden');
                setTimeout(() => overlay.classList.remove('opacity-0'), 10);
            } else {
                sidebar.classList.add('translate-x-full');
                overlay.classList.add('opacity-0');
                setTimeout(() => overlay.classList.add('hidden'), 300);
            }
        }

        function saveOutfit(id) {
            const outfit = currentImages.find(o => o.id === id);
            if (!outfit) return;

            const exists = wardrobe.some(w => w.id === id);
            if (exists) {
                showToast('Outfit already in wardrobe!', 'info');
                return;
            }

            wardrobe.push(outfit);
            updateWardrobeUI();
            showToast('Outfit saved to wardrobe!', 'success');
        }

        function updateWardrobeUI() {
            document.getElementById('wardrobe-count').textContent = wardrobe.length;
            
            const list = document.getElementById('wardrobe-list');
            if (wardrobe.length === 0) {
                list.innerHTML = `
                    <div class="text-center text-gray-500 py-12">
                        <svg class="w-12 h-12 mx-auto mb-3 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path></svg>
                        <p class="text-sm">No saved outfits yet</p>
                        <p class="text-xs mt-1">Generate and save your favorites!</p>
                    </div>
                `;
                return;
            }

            list.innerHTML = wardrobe.map((outfit, index) => `
                <div class="wardrobe-item glass rounded-xl p-4 flex gap-4 items-center group">
                    <div class="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0 bg-surface">
                        <img src="${outfit.imageUrl}" class="w-full h-full object-cover" alt="${outfit.style}" onerror="this.style.display='none'">
                    </div>
                    <div class="flex-1 min-w-0">
                        <h4 class="font-medium text-sm truncate">${outfit.style}</h4>
                        <p class="text-xs text-gray-500 mt-1">${outfit.items.length} items • ${outfit.confidence}% match</p>
                    </div>
                    <button onclick="removeFromWardrobe(${index})" class="p-2 rounded-lg hover:bg-red-500/10 hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                    </button>
                </div>
            `).join('');
        }

        function removeFromWardrobe(index) {
            wardrobe.splice(index, 1);
            updateWardrobeUI();
            showToast('Outfit removed', 'info');
        }

        function clearWardrobe() {
            if (wardrobe.length === 0) return;
            if (!confirm('Clear all saved outfits?')) return;
            
            wardrobe = [];
            updateWardrobeUI();
            showToast('Wardrobe cleared', 'info');
        }

        // Try On (Simulated)
        function tryOnOutfit(id) {
            const outfit = currentImages.find(o => o.id === id);
            if (!outfit) return;
            
            // Show image in modal-like toast
            showToast(`👁️ Previewing: ${outfit.style}`, 'success');
        }

        // Share
        function shareOutfit(id) {
            const outfit = currentImages.find(o => o.id === id);
            if (!outfit) return;
            
            // Copy image URL to clipboard
            navigator.clipboard.writeText(outfit.imageUrl).then(() => {
                showToast('🔗 Image URL copied to clipboard!', 'success');
            }).catch(() => {
                showToast('🔗 Link ready to share!', 'success');
            });
        }

        // Toast Notifications
        function showToast(message, type = 'success') {
            const container = document.getElementById('toast-container');
            const toast = document.createElement('div');
            
            const colors = {
                success: 'border-green-500/30 bg-green-500/10 text-green-400',
                info: 'border-blue-500/30 bg-blue-500/10 text-blue-400',
                error: 'border-red-500/30 bg-red-500/10 text-red-400'
            };

            toast.className = `toast glass px-4 py-3 rounded-xl border ${colors[type]} flex items-center gap-3 shadow-lg`;
            toast.innerHTML = `
                <span class="text-sm font-medium">${message}</span>
            `;

            container.appendChild(toast);
            setTimeout(() => toast.remove(), 3000);
        }

        // Scroll to Generator
        function scrollToGenerator() {
            document.getElementById('generator').scrollIntoView({ behavior: 'smooth' });
        }

        // Demo
        function showDemo() {
            selectCategory('streetwear');
            selectColor(document.querySelector('[data-color="purple"]'));
            updateIntensity(90);
            generateOutfit();
            scrollToGenerator();
        }

        // Initialize
        document.addEventListener('DOMContentLoaded', () => {
            initParticles();
            selectSeason('summer');
        });

        // Keyboard shortcut
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const sidebar = document.getElementById('wardrobe-sidebar');
                if (!sidebar.classList.contains('translate-x-full')) {
                    toggleWardrobe();
                }
            }
        });
    </script>
</body>
</html>
